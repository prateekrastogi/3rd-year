﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExportDataToOfficeApp
{
    public class Car
    {
        public string Make { get; set; }
        public string Color { get; set; }
        public string PetName { get; set; }
    }
}
