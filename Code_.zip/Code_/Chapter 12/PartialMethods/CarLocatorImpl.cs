﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PartialMethods
{
  // CarLocatorImpl.cs
  partial class CarLocator
  {
    // Comment out this entire method to 
    // insert or delete the method from the 
    // assembly. 
    partial void VerifyDuplicates(string make)
    {
      // Assume some expensive data validation
      // takes place here...
    }
  }
}
