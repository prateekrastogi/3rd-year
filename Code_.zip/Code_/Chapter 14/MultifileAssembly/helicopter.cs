using System;

namespace AirVehicles
{
  public class Helicopter
  {
    public void TakeOff()
    {
      Console.WriteLine("Helicopter taking off!");
    }
  }
}
