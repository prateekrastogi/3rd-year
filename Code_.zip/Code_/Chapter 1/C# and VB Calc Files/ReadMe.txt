These files have been provided simply
because they were mentioned in Chapter 1.

If you want to compile this
code into a .NET executable, check out Ch. 2 for full details.

If you want to do so right now, open a Visual Studio 2010 command 
prompt, change to the directory containing this code and enter:

csc *.cs

or to compile the VB code type:

vbc *.vb

- Andrew

PS.  Hope you enjoy the book!