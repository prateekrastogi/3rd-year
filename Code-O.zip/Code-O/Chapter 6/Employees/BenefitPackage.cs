﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Employees
{
    // This is now nested in the employee class. 

    //// This type will function as a contained class.
    //class BenefitPackage
    //{
    //    // Assume we have other members that represent
    //    // 401K plans, dental/health benefits, and so on.
    //    public double ComputePayDeduction()
    //    {
    //        return 125.0;
    //    }
    //}

}
