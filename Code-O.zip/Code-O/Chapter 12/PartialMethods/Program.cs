﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Reflection;

namespace PartialMethods
{
  class Program
  {
    static void Main(string[] args)
    {
      Console.WriteLine("***** Fun with Partial Methods *****\n");
      Console.WriteLine("Load assembly into ildasm to view results");
      Console.ReadLine();
    }
  }
}
