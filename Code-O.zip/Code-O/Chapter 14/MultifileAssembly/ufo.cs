using System;

namespace AirVehicles
{
  public class Ufo
  {
    public void AbductHuman()
    {
      Console.WriteLine("Resistance is futile");
    }
  }
}