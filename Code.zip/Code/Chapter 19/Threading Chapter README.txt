Hello!

When you are running this sample code, make sure you RUN the project (Ctrl+F5)
not DEBUG the project (F5).

If you debug, you will add additional threads into the process, which cause odd 
problems when threads talk to UI controls. 

Just an FYI!

Andrew