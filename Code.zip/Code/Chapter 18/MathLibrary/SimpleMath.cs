﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace MathLibrary
{
    public class SimpleMath
    {
        public int Add(int x, int y)
        { return x + y; }
    }
}
